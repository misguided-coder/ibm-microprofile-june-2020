package com.example.hotel;

import java.util.Properties;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Provider;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.eclipse.microprofile.config.Config;
import org.eclipse.microprofile.config.ConfigProvider;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.config.spi.ConfigProviderResolver;

@Path("/car")
@RequestScoped
public class CarResource {

	@Inject
	@ConfigProperty(name = "car.title")
	String title;

	@Inject
	@ConfigProperty(name = "car.place")
	String place;

	@Inject
	@ConfigProperty(name = "car.total", defaultValue = "50")
	int total;

	@Inject
	@ConfigProperty(name = "car.total")
	Provider<Integer> actualTotal; //dynamic property value injection

	@Inject
	@ConfigProperty(name = "car.types")
	String types;
	
	@Inject
	@ConfigProperty(name = "car.types")
	CarTypes carTypes;
	
	@Inject
	Config config;
	
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/v6")
	public String readDataV6() {
		System.out.println("======  CarResource.readDataV6() ======");
		Config config = ConfigProviderResolver.instance()
						.getBuilder()
						.addDefaultSources()
						.withSources(new DBConfigSource())
						.addDiscoveredConverters()
						.withConverter(CarTypes.class,1,new CarTypesConvertor())
						.build();
		
		String value = config.getValue("car.types", CarTypes.class).toString();
		return value;
	}


	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/v5")
	public Properties readDataV5() {
		System.out.println("======  CarResource.readDataV5() ======");
		Properties properties = new Properties();
		properties.put("name", this.title);
		properties.put("city", this.place);
		properties.put("car-count", this.actualTotal.get());
		properties.put("types", this.types);
		properties.put("car-types", this.carTypes.toString());
		return properties;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/v4")
	public Properties readDataV4() {
		System.out.println("======  CarResource.readDataV4() ======");
		Properties properties = new Properties();
		properties.put("name", config.getValue("car.title", String.class));
		properties.put("city", config.getValue("car.place", String.class));
		properties.put("car-count", config.getValue("car.total", Integer.class));
		return properties;
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/v3")
	public String readDataV3() {
		System.out.println("======  CarResource.readDataV3() ======");
		String value = config.getValue("car.title", String.class);
		return value;
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/v2")
	public String readDataV2() {
		System.out.println("======  CarResource.readDataV2() ======");
		Config config = ConfigProvider.getConfig();
		String value = config.getValue("car.title", String.class);
		return value;
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/v1")
	public String readDataV1() {
		System.out.println("======  CarResource.readDataV1() ======");
		Config config = ConfigProviderResolver.instance().getBuilder().addDefaultSources().build();
		String value = config.getValue("car.title", String.class);
		return value;
	}

}