package com.example.hotel;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.microprofile.config.spi.ConfigSource;

public class DBConfigSource implements ConfigSource {
	
	@Override
	public int getOrdinal() {
		return 900;
	}
	
	//DB Connection
	Map<String, String> inMemoryDB = new HashMap<>();
	
	public DBConfigSource() {
		inMemoryDB.put("car.title", "Dream Cars");
		inMemoryDB.put("car.place", "Dubai");
		inMemoryDB.put("car.total", "1000");
		inMemoryDB.put("car.types", "SUV Sedan");
	}
	
	@Override
	public Map<String, String> getProperties() {
		//DB Select Queury using JDBC to read all properties from corresponding table
		return inMemoryDB;
	}

	@Override
	public String getValue(String propertyName) {
		//DB Select Queury using JDBC to read value from corresponding table
		return inMemoryDB.get(propertyName);
	}

	@Override
	public String getName() {
		return "DBConfigSource";
	}

}
