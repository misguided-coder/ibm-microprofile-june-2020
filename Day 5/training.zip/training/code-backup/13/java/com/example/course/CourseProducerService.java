package com.example.course;

import java.util.concurrent.TimeUnit;

import javax.enterprise.context.ApplicationScoped;

import org.eclipse.microprofile.reactive.messaging.Outgoing;
import org.reactivestreams.Publisher;

import io.reactivex.rxjava3.core.Flowable;

@ApplicationScoped
public class CourseProducerService {

	@Outgoing("new-courses")
	public Publisher<String> produceManyCourses() {
		System.out.println("=====  New course launched =====");
		return Flowable.interval(2, TimeUnit.SECONDS)
					.map((value) -> "Java "+value);
	}
	
	/*@Outgoing("new-courses")
	public Publisher<String> produceManyCourses() {
		System.out.println("=====  New course launched =====");
		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return Flowable.just("Java 14","Hibernae 5","Angular 9");
	}*/
	

	
	/*
	 * @Outgoing("new-courses") public PublisherBuilder<String> produceManyCourses()
	 * { System.out.println("=====  New course launched ====="); try {
	 * TimeUnit.SECONDS.sleep(5); } catch (InterruptedException e) {
	 * e.printStackTrace(); } //return
	 * ReactiveStreams.of("Java 14","Hibernae 5","Angular 9"); return
	 * ReactiveStreams .of("Java 14","Hibernae 5","Angular 9") .map((value) ->
	 * value.toUpperCase()); }
	 */

	/*
	 * @Outgoing("new-courses") public PublisherBuilder<String> produceCourse() {
	 * System.out.println("=====  New course launched ====="); try {
	 * TimeUnit.SECONDS.sleep(5); } catch (InterruptedException e) {
	 * e.printStackTrace(); } //return
	 * ReactiveStreams.of("Java 14","Hibernae 5","Angular 9"); return
	 * ReactiveStreams .of("Java 14","Hibernae 5","Angular 9") .map((value) ->
	 * value.toUpperCase()); }
	 */

}