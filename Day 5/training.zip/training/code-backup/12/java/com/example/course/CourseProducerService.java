package com.example.course;

import java.util.concurrent.TimeUnit;

import javax.enterprise.context.ApplicationScoped;

import org.eclipse.microprofile.reactive.messaging.Outgoing;

@ApplicationScoped
public class CourseProducerService {

	@Outgoing("new-courses")
	public String produceCourse() {
		System.out.println("=====  New course launched =====");
		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return "Java 14";
	}

}