package com.example.course;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.enterprise.context.ApplicationScoped;

import org.eclipse.microprofile.reactive.messaging.Incoming;

@ApplicationScoped
public class CoursePriceSetterService {

	List<String> courses = new CopyOnWriteArrayList<>();

	public List<String> getCourses() {
		return courses;
	}

	@Incoming("approved-courses")
	public void decidePriceForCource(String message) {
		System.out.println("=====  Course price set =====");
		courses.add(message + " with price Rs/- 350000.");
	}

}