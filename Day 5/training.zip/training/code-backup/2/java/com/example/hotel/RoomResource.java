package com.example.hotel;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/room")
public class RoomResource {

	public RoomResource() {
		System.out.println("======  RoomResource ======");
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String howManyAvailable() {
		System.out.println("======  RoomResource.howManyAvailable() ======");
		return "{\"emptyRooms\":12}";
	}
	
}