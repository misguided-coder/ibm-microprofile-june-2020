package com.example.course;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.reactive.messaging.Incoming;
import org.eclipse.microprofile.reactive.messaging.Outgoing;

@Path("/course")
@ApplicationScoped
public class CourseResource {

	List<String> courses = new CopyOnWriteArrayList<>();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/list")
	public Response showAvailableCourses() {
		System.out.println("======  CarResource.showAvailableCourses() ======");
		return Response.ok().entity(courses).build();
	}

	// Create producer and setup a new channel then start producing messages
	@Outgoing("new-courses")
	public String produceCourse() {
		System.out.println("=====  New course launched =====");
		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return "Java 14";
	}

	// Create subscriber and subscribe to an already existing channel then start
	// receiving messages
	// Create producer also to produce approved courses
	@Incoming("new-courses")
	@Outgoing("approved-courses")
	public String approveCourse(String message) {
		System.out.println("=====  Course approved =====");
		return "Approved : " + message;
	}

	// Create subscriber and subscribe to an already existing channel then start
	// receiving messages
	@Incoming("approved-courses")
	public void decidePriceForCource(String message) {
		System.out.println("=====  Course price set =====");
		courses.add(message + " with price Rs/- 350000.");
	}

}