package com.example;

import java.time.temporal.ChronoUnit;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.faulttolerance.Bulkhead;
import org.eclipse.microprofile.faulttolerance.CircuitBreaker;
import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.faulttolerance.Retry;
import org.eclipse.microprofile.faulttolerance.Timeout;

@Path("/pizza")
@ApplicationScoped
public class PizzaMS {

	// isolate failures in the half system
	@Bulkhead(value = 3, waitingTaskQueue = 7)
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/eat")
	public Response eatPizzaAtRestaurent() {
		System.out.println("======  PizzaMS.eatPizzaAtRestaurent() ======");
		// Some back end service call made and service is already fully occupied and
		// already almost about to crash or has crashed i.e. RestaurentMS

		try {
			TimeUnit.SECONDS.sleep(4);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		Random random = new Random(1000);

		if (random.nextInt() > 500)
			throw new RuntimeException("RestaurentMS is crshed!!");
		else
			return Response.ok().entity("Farm House pizza can be taken home!!").build();
	}
	
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/deliver/v2")
	public Response deliverPizzaV2() {
		System.out.println("======  PizzaMS.deliverPizzaV2() ======");
		// Some back end service call made and service is currently down and unavailable
		// plus will be down for some more time i.e. PizzaDeliveryMS

		Random random = new Random(1000);

		if (random.nextInt() > 500)
			throw new RuntimeException("PizzaDeliveryMS is unavailable!!");
		else
			return Response.ok().entity("Farm House pizza will be delivered in 30 minutes!!").build();
	}


	
	// CB is open and API should fail fast/immediately because half system is down
	// and will be down so return
	// default response to callers immediately
	@CircuitBreaker(requestVolumeThreshold = 6, failureRatio = 0.50, successThreshold = 4, delay = 10, delayUnit = ChronoUnit.SECONDS)
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/deliver/v1")
	public Response deliverPizzaV1() {
		System.out.println("======  PizzaMS.deliverPizzaV1() ======");
		// Some back end service call made and service is currently down and unavailable
		// plus will be down for some more time i.e. PizzaDeliveryMS

		Random random = new Random(1000);

		if (random.nextInt() > 500)
			throw new RuntimeException("PizzaDeliveryMS is unavailable!!");
		else
			return Response.ok().entity("Farm House pizza will be delivered in 30 minutes!!").build();
	}

	// retry policy to wait for system to become available and working
	@Retry(maxDuration = 10, durationUnit = ChronoUnit.SECONDS, maxRetries = 5, delay = 500, delayUnit = ChronoUnit.MILLIS, jitter = 100, jitterDelayUnit = ChronoUnit.MILLIS, retryOn = IndexOutOfBoundsException.class, abortOn = RuntimeException.class)
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/order/v2")
	public Response orderForPizzaV2() {
		System.out.println("======  PizzaMS.orderForPizzaV2() ======");
		// Some service call made and service is currently unavailable, may be some
		// network issue i.e. PizzaReataurantMS

		int quantity = (int) (Math.floor(Math.random() * 1000));

		if (quantity > 800) {
			throw new RuntimeException("Pizza order attempted with quantity " + quantity);
		} else if (quantity > 400) {
			throw new ArithmeticException("Pizza order attempted  with quantity " + quantity);
		} else if (quantity > 100) {
			throw new IndexOutOfBoundsException("Pizza order attempted  with quantity " + quantity);
		}

		return Response.ok().entity("Farm House pizza ordered.").build();
	}

	// limit the duration of API call
	@Timeout(value = 5, unit = ChronoUnit.SECONDS) // trying to meet client SLA, very strict response time
	@Fallback(fallbackMethod = "orderForPanPizza")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/order/v1")
	public Response orderForPizzaV1() {
		System.out.println("======  PizzaMS.orderForPizzaV1() ======");
		// Some service call made and taking too much time to respond i.e.
		// PizzaReataurantMS
		try {
			TimeUnit.SECONDS.sleep(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return Response.ok().entity("Farm House pizza ordered.").build();
	}

	public Response orderForPanPizza() {
		System.out.println("======  PizzaMS.orderForPanPizza() ======");
		return Response.ok().entity("Farm House Pan Pizza ordered.").build();
	}

	// @Fallback(fallbackMethod="payForPizzaByUPI")
	@Fallback(fallbackMethod = "payForPizzaByUPI", applyOn = RuntimeException.class, skipOn = ArithmeticException.class)
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/pay/{amount}")
	public Response payForPizza(@PathParam("amount") double amount) {
		System.out.println("======  PizzaMS.payForPizza() ======");
		// Some service call failed and did return exception i.e. MasterCardPaymentMS
		if (amount < 100.00) {
			throw new RuntimeException();
		} else if (amount < 500.00) {
			throw new ArithmeticException();
		}
		return Response.ok().entity(amount + " Rs/- Paid By Master Card").build();
	}

	public Response payForPizzaByUPI(double amount) {
		System.out.println("======  PizzaMS.payForPizzaByUPI() ======");
		// Some service call failed and did return exception i.e. UPIPaymentMS
		return Response.ok().entity(amount + " Rs/- Paid By UPI").build();
	}

}