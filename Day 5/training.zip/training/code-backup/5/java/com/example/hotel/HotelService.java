package com.example.hotel;

import java.util.Collection;

public interface HotelService {

	public Collection<Hotel> readAllHotels();

	public Hotel readHotel();

	public Hotel readHotelById(int hotelId);

}
