package com.example.hotel;

import java.util.Collection;

import javax.enterprise.inject.spi.CDI;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/")
public class HotelResource {

	@Inject
	HotelService hotelService;

	public HotelResource() {
		System.out.println("======  HotelResource ======");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/v3")
	public Hotel getHotelV3() {
		System.out.println("======  HotelResource.getHotelV3() ======");
		
		//CDI<Object> container = CDI.current();
		//Programitically asking bean reference from DI Container
		//Instance<HotelService> instance = container.select(HotelService.class);
		//HotelService hotelService = instance.get();
		//HotelService hotelService = container.select(HotelService.class).get();
		//HotelService hotelService = CDI.current().select(HotelService.class).get();
		//return hotelService.readHotel();
		return CDI.current().select(HotelService.class).get().readHotel();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/v2")
	public Hotel getHotelV2() {
		System.out.println("======  HotelResource.getHotelV2() ======");
		// Make call to business services and will return application specific domain
		// object
		return hotelService.readHotel();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/v1")
	public Hotel getHotelV1() {
		System.out.println("======  HotelResource.getHotelV1() ======");
		// Make call to business services and will return application specific domain
		// object
		HotelService hotelService = new HotelServiceImpl();
		return hotelService.readHotel();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/list")
	public Collection<Hotel> getHotelList() {
		System.out.println("======  HotelResource.getHotelList() ======");
		return hotelService.readAllHotels();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/find/{id}")
	public Hotel findHotel(@PathParam("id") int hotelId) {
		System.out.println("======  HotelResource.findHotel() ======");
		return hotelService.readHotelById(hotelId);
	}

}