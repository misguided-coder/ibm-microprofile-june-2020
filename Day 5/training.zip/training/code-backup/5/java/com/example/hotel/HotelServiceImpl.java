package com.example.hotel;

import java.time.LocalDate;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class HotelServiceImpl implements HotelService {
	
	Map<Integer,Hotel> inMemoryDB = new ConcurrentHashMap<>();

	@PostConstruct
	public void init() {
		System.out.println("===== Inside HotelServiceImpl init() =====");
		inMemoryDB.put(1000,new Hotel(1000, "Taj Palace", "New Delhi", 600, LocalDate.now()));
		inMemoryDB.put(1001,new Hotel(1001, "Hyatt", "New Delhi", 400, LocalDate.now()));
		inMemoryDB.put(1002,new Hotel(1002, "Radisson", "New Delhi", 200, LocalDate.now()));
		inMemoryDB.put(1003,new Hotel(1003, "Holiday Inn", "New Delhi", 600, LocalDate.now()));
	}

	@PreDestroy
	public void clean() {
		System.out.println("===== Inside HotelServiceImpl clean() =====");
		inMemoryDB.clear();
		inMemoryDB = null;
	}

	@Override
	public Collection<Hotel> readAllHotels() {
		System.out.println("======  HotelServiceImpl.readAllHotels() ======");
		return inMemoryDB.values();
	}

	@Override
	public Hotel readHotel() {
		System.out.println("======  HotelServiceImpl.readHotel() ======");
		return inMemoryDB.get(1003);
	}

	@Override
	public Hotel readHotelById(int hotelId) {
		System.out.println("======  HotelServiceImpl.readHotelById() ======");
		return inMemoryDB.get(hotelId);
	}

}
