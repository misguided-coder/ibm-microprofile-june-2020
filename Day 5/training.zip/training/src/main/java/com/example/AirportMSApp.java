package com.example;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/api")
public class AirportMSApp extends Application {

	public AirportMSApp() {
		System.out.println("===== AirportMSApp.constructor()  =====");
	}

	@Override
	public Set<Class<?>> getClasses() {
		System.out.println("===== AirportMSApp.getClasses()  =====");
		Set<Class<?>> classes = new HashSet<>();
		classes.add(AirportMS.class);
		return classes;
	}

}
