package com.example;

import java.util.Properties;
import java.util.Set;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.enterprise.context.ApplicationScoped;

@Path("/airport")
@ApplicationScoped
public class AirportMS {

	@Inject
	AirportService airportService;

	@PostConstruct
	public void init() {
		System.out.println("===== AirportMS.init()  =====");
	}

	@PreDestroy
	public void clean() {
		System.out.println("===== AirportMS.clean()  =====");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Set<String> listAirports() {
		return airportService.listAirports();
	}

	@GET
	@Path("/{airportcode}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAirportDetailsByCode(@PathParam("airportcode") String airportCode) {
		Airport airport = airportService.getAirport(airportCode);
		if (airport == null) {
			return Response.status(Response.Status.NOT_FOUND).entity("ERROR: Unknown airport code").build();
		}
		return Response.ok().entity(airport).build();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/airlines")
	public Set<String> listAirlines() {
		return airportService.listAirlines();
	}
}
