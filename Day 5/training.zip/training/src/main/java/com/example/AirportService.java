package com.example;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class AirportService {

	private Map<String, Airport> airports = new ConcurrentHashMap<>();
	Set<String> airlines = new HashSet<>();

	@PostConstruct
	public void init() {
		System.out.println("===== AirportService.init()  =====");

		airlines.add("I5"); // AirAsia India
		airlines.add("AI"); // Air India
		airlines.add("IX"); // Air India Express
		airlines.add("G8"); // GoAir
		airlines.add("6E"); // IndiGo
		airlines.add("9W"); // Jet Airways
		airlines.add("SG"); // SpiceJet
		airlines.add("UK"); // Vistara

		airports.put("DEL", new Airport("DEL", "Indira Gandhi International Airport", "New Delhi", true, 530, 40000,
				"GMR", airlines));

		airports.put("BOM", new Airport("BOM", "Chhatrapati Shivaji International Airport", "Mumbai", true, 410, 34000,
				"GMR", airlines));

		airports.put("MAA",
				new Airport("MAA", "Chennai International Airport", "Chennai", true, 510, 38000, "GMR", airlines));

		airports.put("CCU", new Airport("CCU", "Netaji Subhash Chandra Bose International Airport", "Calcutta", true,
				450, 30000, "AAI", airlines));

		airports.put("HYD", new Airport("HYD", "Rajiv Gandhi International Airport", "Hyderabad", true, 650, 60000,
				"GMR", airlines));

		airports.put("BLR",
				new Airport("BLR", "Kempegowda International Airport", "Bangalore", true, 700, 65000, "GMR", airlines));

		airports.put("PNQ", new Airport("PNQ", "Lohegaon Airport", "Pune", false, 120, 5000, "AAI", airlines));

		airports.put("GOI", new Airport("GOI", "Dabolim Airport", "GOA", true, 150, 7000, "AAI", airlines));

		airports.put("DED", new Airport("DED", "Jolly Grant Airport", "Dehradun", false, 40, 2000, "AAI", airlines));

		airports.put("VTZ",
				new Airport("VTZ", "Vishakhapatnam Airport", "Vishakhapatnam", false, 40, 6000, "AAI", airlines));

	}

	@PreDestroy
	public void clean() {
		System.out.println("===== AirportService.clean()  =====");
		airports.clear();
		airports = null;
	}

	public Set<String> listAirports() {
		System.out.println("===== AirportService.listAirports()  =====");
		return airports.keySet();
	}

	public Airport getAirport(String airportCode) {
		System.out.println("===== AirportService.getAirport()  =====");
		return airports.get(airportCode.toUpperCase());
	}

	public Set<String> listAirlines() {
		System.out.println("===== AirportService.listAirlines()  =====");
		return airlines;
	}

}
