package com.example;

import java.util.Set;

public class Airport {

	String code;
	String name;
	String city;
	boolean international;
	int dailyFlights;
	int dailyPassengers;
	String managedBy;
	Set<String> airlines;

	public Airport() {
	}
	
	public Airport(String code, String name, String city, boolean international, int dailyFlights, int dailyPassengers,
			String managedBy, Set<String> airlines) {
		super();
		this.code = code;
		this.name = name;
		this.city = city;
		this.international = international;
		this.dailyFlights = dailyFlights;
		this.dailyPassengers = dailyPassengers;
		this.managedBy = managedBy;
		this.airlines = airlines;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public boolean isInternational() {
		return international;
	}

	public void setInternational(boolean international) {
		this.international = international;
	}

	public Set<String> getAirlines() {
		return airlines;
	}

	public void setAirlines(Set<String> airlines) {
		this.airlines = airlines;
	}

	public int getDailyFlights() {
		return dailyFlights;
	}

	public void setDailyFlights(int dailyFlights) {
		this.dailyFlights = dailyFlights;
	}

	public int getDailyPassengers() {
		return dailyPassengers;
	}

	public void setDailyPassengers(int dailyPassengers) {
		this.dailyPassengers = dailyPassengers;
	}

	public String getManagedBy() {
		return managedBy;
	}

	public void setManagedBy(String managedBy) {
		this.managedBy = managedBy;
	}

}
