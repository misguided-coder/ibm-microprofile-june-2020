public class TravelService {  
	public static void main(String[] args){  
		System.out.println("Now is the right time to travel everywhere in a Docker container!!");  
	}  
}  