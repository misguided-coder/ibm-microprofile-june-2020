package com.example.hotel.frontdesk;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.sse.Sse;

import org.eclipse.microprofile.reactive.messaging.Incoming;

@Path("/frontdesk")
@ApplicationScoped
public class FrontDeskMS {

	Map<String, String> map = new ConcurrentHashMap<>();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/inquire")
	public Response bookRoom() {
		System.out.println("======  FrontDeskMS.bookRoom() ======");
		return Response.ok().entity(map).build();
	}

	@Incoming("hotel-message-bus-in")
	public void pickRoomsInfo(String info) {
		System.out.println("======  FrontDeskMS.pickRoomsInfo() ====== "+info);
		String[] array = info.split(",");
		map.put(array[0], array[1]);
	}

}