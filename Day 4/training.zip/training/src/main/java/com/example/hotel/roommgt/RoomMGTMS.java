package com.example.hotel.roommgt;

import java.util.concurrent.TimeUnit;

import javax.enterprise.context.ApplicationScoped;

import org.eclipse.microprofile.reactive.messaging.Outgoing;

@ApplicationScoped
public class RoomMGTMS {

	String[] roomTypes = { "Luxury", "Standard", "Family", "Elite", "Budget" };

	@Outgoing("hotel-message-bus-out")
	public String updateRoomsAvailability() {
		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		int idx = (int) (Math.floor(Math.random() * roomTypes.length));
		String availableRooms = new Integer(idx + 10).toString();
		String roomInfo = roomTypes[idx]+","+availableRooms;
		System.out.println("======  RoomMGTMS.updateRoomsAvailability() ======"+roomInfo);
		return roomInfo;
	}

}