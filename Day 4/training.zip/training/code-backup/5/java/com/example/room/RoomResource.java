package com.example.room;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/room")
public class RoomResource {

	//@Inject
	//@Delux
	RoomService roomService;
	
	
	@Inject
	public void setRoomService(@Delux RoomService roomService) {
		this.roomService = roomService;
	}

	public RoomResource() {
		System.out.println("======  RoomResource ======");
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/v1")
	public String bookRoomV1() {
		System.out.println("======  RoomResource.bookRoomV1() ======");
		String response = roomService.makeRoomBooking();
		return response;
	}

}