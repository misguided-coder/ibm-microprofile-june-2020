package com.example.room;

@Elite
public class EliteRoomService implements RoomService {

	@Override
	public String makeRoomBooking() {
		System.out.println("======  EliteRoomService.makeRoomBooking() ======");
		// 500 LOC
		return "Elite Room Booked";
	}
}
