package com.example.room;

@Delux
public class DeluxRoomService implements RoomService {

	@Override
	public String makeRoomBooking() {
		System.out.println("======  DeluxRoomService.makeRoomBooking() ======");
		// 500 LOC
		return "Delux Room Booked";
	}
}
