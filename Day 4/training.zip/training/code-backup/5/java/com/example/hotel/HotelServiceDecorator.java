package com.example.hotel;

import java.util.Collection;

import javax.decorator.Decorator;
import javax.decorator.Delegate;
import javax.inject.Inject;

@Decorator
public abstract class HotelServiceDecorator implements HotelService {

	@Inject
	@Delegate
	HotelServiceImpl hotelService;
	
	@Override
	public Collection<Hotel> readAllHotels() {
		System.out.println("======  HotelServiceDecorator adding extra functionality to readAllHotels() ======");
		//Delegate call to original bean functionality
		return hotelService.readAllHotels();
	}

	@Override
	public Hotel readHotelById(int hotelId) {
		System.out.println("======  HotelServiceDecorator adding extra functionality to readHotelById("+hotelId+") ======");
		if(hotelId >= 1000 || hotelId <= 1003) {
			return hotelService.readHotelById(hotelId);
		}
		return new Hotel();
	}
}
