package com.example.room;

public interface RoomService {
	
	public abstract String makeRoomBooking();
}
