package com.example.hotel;

import java.util.ArrayList;
import java.util.List;

public class CarTypes {

	List<String> values = new ArrayList<>();

	public List<String> getValues() {
		return values;
	}

	public void setValues(List<String> values) {
		this.values = values;
	}

	@Override
	public String toString() {
		return "CarTypes [values=" + values + "]";
	}
	
}
