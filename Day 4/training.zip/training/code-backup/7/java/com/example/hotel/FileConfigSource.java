package com.example.hotel;

import java.io.FileReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import org.eclipse.microprofile.config.spi.ConfigSource;

public class FileConfigSource implements ConfigSource {

	@Override
	public int getOrdinal() {
		return 1200;
	}

	Map<String, String> inMemoryStore = new HashMap<>();

	public FileConfigSource() {
		Properties properties = new Properties();
		String path = "C:\\ibm-microprofile-workspace\\training\\src\\main\\resources\\META-INF\\application.properties";
		try(FileReader fileReader = new FileReader(path)){
			properties.load(fileReader);
			System.out.println("FileConfigSource ====>  Property Data Loaded in memory!!");
			Iterator<Object> itr = properties.keySet().iterator();
			while(itr.hasNext()) {
				String key = (String) itr.next();
				inMemoryStore.put(key, properties.getProperty(key));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public Map<String, String> getProperties() {
		// DB Select Queury using JDBC to read all properties from corresponding table
		return inMemoryStore;
	}

	@Override
	public String getValue(String propertyName) {
		// DB Select Queury using JDBC to read value from corresponding table
		return inMemoryStore.get(propertyName);
	}

	@Override
	public String getName() {
		return "FileConfigSource";
	}

}
