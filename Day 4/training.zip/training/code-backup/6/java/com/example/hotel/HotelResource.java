package com.example.hotel;

import java.util.Collection;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/")
@RequestScoped
public class HotelResource {

	@Inject
	HotelService hotelService;

	@PostConstruct
	public void init() {
		System.out.println("===== Inside HotelResource init() =====");
	}

	@PreDestroy
	public void clean() {
		System.out.println("===== Inside HotelResource clean() =====");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Collection<Hotel> getAll() {
		System.out.println("======  HotelResource.getAll() ======");
		return hotelService.listAll();
	}

}