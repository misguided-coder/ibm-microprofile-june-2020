package com.example.hotel;

import java.time.LocalDate;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class HotelService {

	Map<Integer, Hotel> inMemoryDB = new ConcurrentHashMap<>();

	@PostConstruct
	public void init() {
		System.out.println("===== Inside HotelService init() =====");
		inMemoryDB.put(1000, new Hotel(1000, "Taj Palace", "New Delhi", 600, LocalDate.now()));
		inMemoryDB.put(1001, new Hotel(1001, "Hyatt", "New Delhi", 400, LocalDate.now()));
		inMemoryDB.put(1002, new Hotel(1002, "Radisson", "New Delhi", 200, LocalDate.now()));
		inMemoryDB.put(1003, new Hotel(1003, "Holiday Inn", "New Delhi", 600, LocalDate.now()));
	}

	@PreDestroy
	public void clean() {
		System.out.println("===== Inside HotelService clean() =====");
		inMemoryDB.clear();
		inMemoryDB = null;
	}

	public Collection<Hotel> listAll() {
		System.out.println("======  HotelService.listAll() ======");
		return inMemoryDB.values();
	}

}
