package com.example.course;

import javax.enterprise.context.ApplicationScoped;

import org.eclipse.microprofile.reactive.messaging.Incoming;
import org.eclipse.microprofile.reactive.messaging.Message;
import org.eclipse.microprofile.reactive.messaging.Outgoing;

@ApplicationScoped
public class CourseApproverService {

	@Incoming("new-courses")
	@Outgoing("approved-courses")
	public String approveCourse(Message<String> message) {
		System.out.println("=====  Course approved =====");
		return "Approved : " + message.getPayload();
	}

}