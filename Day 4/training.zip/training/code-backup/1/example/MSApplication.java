package com.example;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

//@ApplicationPath("/api")
public class MSApplication extends Application {

	public MSApplication(){
		System.out.println("======  MSApplication  ======");
	}
	
	@Override
	public Set<Object> getSingletons() {
		System.out.println("======  MSApplication.getSingletons()  ======");
		Set<Object> resources = new HashSet<>();
		resources.add(new PersonResource());
		return resources;
	}
	
	@Override
	public Set<Class<?>> getClasses() {
		System.out.println("======  MSApplication.getClasses()  ======");
		Set<Class<?>> resources = new HashSet<>();
		//resources.add(PersonResource.class);
		resources.add(CarResource.class);
		resources.add(HotelResource.class);
		return resources;
	}
			
}