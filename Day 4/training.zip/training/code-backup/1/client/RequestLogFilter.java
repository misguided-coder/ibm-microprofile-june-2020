package com.example.client;

import java.io.IOException;
import java.util.Set;

import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientResponseContext;
import javax.ws.rs.client.ClientResponseFilter;
import javax.ws.rs.core.MultivaluedMap;

public class RequestLogFilter implements ClientResponseFilter {

	@Override
	public void filter(ClientRequestContext requestContext, ClientResponseContext responseContext) throws IOException {
		System.out.println("INFO ==>>> RequestLogFilter");
		System.out.println("Request URI  : "+requestContext.getUri().toString());
		MultivaluedMap<String, String> headers = responseContext.getHeaders();
		Set<String> names = headers.keySet();
		for(String name : names) {
			System.out.println(name+" ----  "+headers.get(name));
		}
	}

}
