package com.example.client;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("person")
public interface IPersonResource {

	@GET
	@Produces(MediaType.APPLICATION_JSON)   //Accept=application/json
	public String info();
	
	@GET // HTTP - GET
	@Produces(MediaType.TEXT_PLAIN)  //Accept=text/plain
	public String details();
	
}