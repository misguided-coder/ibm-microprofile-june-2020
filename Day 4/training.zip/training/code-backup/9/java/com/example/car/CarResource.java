package com.example.car;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.metrics.Histogram;
import org.eclipse.microprofile.metrics.Metadata;
import org.eclipse.microprofile.metrics.MetadataBuilder;
import org.eclipse.microprofile.metrics.MetricRegistry;
import org.eclipse.microprofile.metrics.MetricUnits;
import org.eclipse.microprofile.metrics.annotation.Counted;
import org.eclipse.microprofile.metrics.annotation.Gauge;
import org.eclipse.microprofile.metrics.annotation.Metered;
import org.eclipse.microprofile.metrics.annotation.RegistryType;
import org.eclipse.microprofile.metrics.annotation.Timed;

@Path("/car")
@ApplicationScoped
public class CarResource {

	@Inject
	@RegistryType(type = MetricRegistry.Type.APPLICATION)
	MetricRegistry metricRegistry;

	@GET
	@Produces({ MediaType.TEXT_PLAIN })
	@Path("/luxury/inventory")
	public Response checkInventory() {
		int carsInInventory = 500;
		System.out.println("======  CarResource.checkInventory() ======");
		Metadata metadata = new MetadataBuilder()
				.withName("checkInventoryMetric")
				.withDescription("Metric to check the distribution of values!!")
				.withUnit(MetricUnits.NONE).build();
		Histogram histogram = this.metricRegistry.histogram(metadata);
		histogram.update((carsInInventory + (int)(Math.random()* 200)));
		return Response.ok().build();
	}

	@GET
	@Produces({ MediaType.TEXT_PLAIN })
	@Path("/luxury/sell")
	public int luxuryCarsSold() {
		System.out.println("======  CarResource.luxuryCarsSold() ======");
		Metadata metadata = new MetadataBuilder().withName("luxuryCarsSoldCounter")
				.withDescription("Metric to count number of invocations").withUnit(MetricUnits.NONE).build();
		this.metricRegistry.counter(metadata).inc(10);
		int carsSold = 500;
		return carsSold;
	}

	@Metered(name = "availableCarsAccessTime", description = "Metrics to show the throughput of the availableCars API in different precentile", absolute = true)
	@GET
	@Produces({ MediaType.TEXT_PLAIN })
	@Path("/ready")
	public Response availableCars() {
		System.out.println("======  CarResource.availableCars() ======");
		return Response.ok().build();
	}

	@Gauge(unit = "number", absolute = true)
	@GET
	@Produces({ MediaType.TEXT_PLAIN })
	@Path("/sell")
	public int sellCar() {
		System.out.println("======  CarResource.sellCar() ======");
		int carsSold = 120;
		return carsSold;
	}

	@Counted(name = "readCarCounter", reusable = true, absolute = true, description = "Metrics to collect number of invocation to readCar API", displayName = "Read Cars", tags = "appName=CarsApp,method=readCar")
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	public Response readCar() {
		System.out.println("======  CarResource.readCar() ======");
		// Make call to Service and read car
		Car car = new Car(1000, "Q5", "Audi", 780000.00);
		return Response.ok().entity(car).build();
	}

	@Counted(name = "readCarByVINCounter", reusable = true, absolute = true, description = "Metrics to collect number of invocation to readCarByVIN API", displayName = "Read Cars only by VIN", tags = "appName=CarsApp,method=readCarByVIN")
	// @SimplyTimed(
	@Timed(name = "readCarAccessTime", unit = MetricUnits.SECONDS, absolute = true, description = "Metrics to collect access time  of readCarByVIN API", displayName = "Read Cars By VIN", tags = "appName=CarsApp,method=readCarByVIN")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("{vin}")
	public Car readCarByVIN(@PathParam("vin") int vin) {
		System.out.println("======  CarResource.readCarByVIN() ======");
		return new Car(vin, "Q5", "Audi", 780000.00);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Car addCar(Car car) {
		System.out.println("======  CarResource.addCar() ======");
		car.setVin((int) (Math.random() * 2000));
		return car;
	}

}