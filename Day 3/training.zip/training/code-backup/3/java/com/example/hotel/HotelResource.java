package com.example.hotel;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/")
public class HotelResource {

	public HotelResource() {
		System.out.println("======  HotelResource ======");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/luxury/v2")
	public JsonArray allLuxuryHotelsV2() {
		System.out.println("======  HotelResource.allLuxuryHotelsV2() ======");

		return Json.createArrayBuilder().add("Luxury Hotels").add("***** hotels")
				.add(Json.createObjectBuilder().add("title", "Radisson")
						.add("place",
								Json.createObjectBuilder().add("city", "Ahmedabad").add("state", "Gujrat").build())
						.add("rooms", 300).build())
				.add(Json.createObjectBuilder().add("title", "Radisson").add("place", "New Delhi").add("rooms", 300)
						.build())
				.add(Json.createObjectBuilder().add("title", "Hyatt").add("place", "New Delhi").add("rooms", 360)
						.build())
				.build();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/luxury/v1")
	public JsonArray allLuxuryHotelsV1() {
		System.out.println("======  HotelResource.allLuxuryHotelsV1() ======");

		JsonObject jsonObject1 = Json.createObjectBuilder().add("title", "Radisson").add("place", "New Delhi")
				.add("rooms", 300).build();
		JsonObject jsonObject2 = Json.createObjectBuilder().add("title", "Taj Palace").add("place", "New Delhi")
				.add("rooms", 500).build();

		JsonObject jsonObject3 = Json.createObjectBuilder().add("title", "Hyatt").add("place", "New Delhi")
				.add("rooms", 360).build();

		JsonArrayBuilder jsonArrayBuilder = Json.createArrayBuilder();
		jsonArrayBuilder.add(jsonObject1);
		jsonArrayBuilder.add(jsonObject2);
		jsonArrayBuilder.add(jsonObject3);

		return jsonArrayBuilder.build();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/all")
	public JsonArray allHotels() {
		System.out.println("======  HotelResource.allHotels() ======");
		JsonArrayBuilder jsonArrayBuilder = Json.createArrayBuilder();
		jsonArrayBuilder.add("Radisson Blu,Dwarka");
		jsonArrayBuilder.add("Radisson Blu,Delhi Airoprt");
		jsonArrayBuilder.add("Radisson Blu,Mahipalpur");
		jsonArrayBuilder.add("Hyatt,RKPuram");
		JsonArray jsonArray = jsonArrayBuilder.build();
		return jsonArray;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/list")
	public String listHotels() {
		System.out.println("======  HotelResource.listHotels() ======");
		JsonArrayBuilder jsonArrayBuilder = Json.createArrayBuilder();
		jsonArrayBuilder.add("Radisson Blu,Dwarka");
		jsonArrayBuilder.add("Radisson Blu,Delhi Airoprt");
		jsonArrayBuilder.add("Radisson Blu,Mahipalpur");
		jsonArrayBuilder.add("Hyatt,RKPuram");
		JsonArray jsonArray = jsonArrayBuilder.build();
		return jsonArray.toString();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/v5")
	public Hotel getHotelV5() {
		System.out.println("======  HotelResource.getHotelV5() ======");

		//Received this json object from another MS by calling it
		JsonObject jsonObject = Json.createObjectBuilder()
				.add("id", 1001)
				.add("title", "Radisson Blu")
				.add("place", "New Delhi")
				.add("rooms", 300)
				.build();

		return new Hotel(jsonObject.getInt("id"),jsonObject.getString("title"),jsonObject.getString("place"),jsonObject.getInt("rooms"));
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/v4")
	public Hotel getHotelV4() {
		System.out.println("======  HotelResource.getHotelV4() ======");

		// Make call to business services and will return application specific domain
		// object
		Hotel hotel = new Hotel(1000, "Taj Palace", "New Delhi", 600);

		return hotel;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/v3")
	public JsonObject getHotelV3() {
		System.out.println("======  HotelResource.getHotelV3() ======");

		// Make call to business services and will return application specific domain
		// object
		Hotel hotel = new Hotel(1000, "Taj Palace", "New Delhi", 600);

		// Converting from Java POJO to Json Object
		return Json.createObjectBuilder().add("id", hotel.getId()).add("title", hotel.getTitle())
				.add("place", hotel.getPlace()).add("rooms", hotel.getRooms()).build();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/v2")
	public JsonObject getHotelV2() {
		System.out.println("======  HotelResource.getHotelV2() ======");
		JsonObjectBuilder jsonObjectBuilder = Json.createObjectBuilder();
		jsonObjectBuilder.add("title", "Radisson Blu");
		jsonObjectBuilder.add("place", "New Delhi");
		jsonObjectBuilder.add("rooms", 300);
		JsonObject jsonObject = jsonObjectBuilder.build();
		return jsonObject;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/v1")
	public String getHotelV1() {
		System.out.println("======  HotelResource.getHotelV1() ======");
		JsonObjectBuilder jsonObjectBuilder = Json.createObjectBuilder();
		jsonObjectBuilder.add("title", "Radisson Blu");
		jsonObjectBuilder.add("place", "New Delhi");
		jsonObjectBuilder.add("rooms", 300);
		JsonObject jsonObject = jsonObjectBuilder.build();
		return jsonObject.toString();
	}

}