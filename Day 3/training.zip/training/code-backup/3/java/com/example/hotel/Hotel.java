package com.example.hotel;

public class Hotel {

	int id;
	String title;
	String place;
	int rooms;

	public Hotel() {
	}

	public Hotel(String title, String place, int rooms) {
		this.title = title;
		this.place = place;
		this.rooms = rooms;
	}

	public Hotel(int id, String title, String place, int rooms) {
		this.id = id;
		this.title = title;
		this.place = place;
		this.rooms = rooms;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public int getRooms() {
		return rooms;
	}

	public void setRooms(int rooms) {
		this.rooms = rooms;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + ((place == null) ? 0 : place.hashCode());
		result = prime * result + rooms;
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Hotel other = (Hotel) obj;
		if (id != other.id)
			return false;
		if (place == null) {
			if (other.place != null)
				return false;
		} else if (!place.equals(other.place))
			return false;
		if (rooms != other.rooms)
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Hotel [id=" + id + ", title=" + title + ", place=" + place + ", rooms=" + rooms + "]";
	}

}
