package com.example.car;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/car")
public class CarApplication extends Application {

	public CarApplication() {
		System.out.println("======  CarApplication  ======");
	}

	@Override
	public Set<Class<?>> getClasses() {
		System.out.println("======  CarApplication.getClasses()  ======");
		Set<Class<?>> resources = new HashSet<>();
		resources.add(CarResource.class);
		return resources;
	}

}