package com.example.hotel;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/")
public class HotelResource {

	public HotelResource() {
		System.out.println("======  HotelResource ======");
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String info() {
		System.out.println("======  HotelResource.info() ======");
		return "{\"title\":\"Radisson\",\"place\":\"Delhi\"}";
	}
	
}