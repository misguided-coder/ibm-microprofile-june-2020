package com.example.hotel;

import org.eclipse.microprofile.config.spi.Converter;

public class CarTypesConvertor implements Converter<CarTypes> {

	@Override
	public CarTypes convert(String value) {
		System.out.println("========== CarTypesConvertor.convert() =============");
		CarTypes carTypes = new CarTypes();
		String[] array = value.split(" ");
		for(String element : array) {
			carTypes.getValues().add(element);
		}
		return carTypes;
	}
}
