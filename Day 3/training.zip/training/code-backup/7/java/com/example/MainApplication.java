package com.example;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.example.hotel.CarResource;

@ApplicationPath("/api")
public class MainApplication extends Application {

	public MainApplication() {
		System.out.println("======  MainApplication  ======");
	}

	@Override
	public Set<Class<?>> getClasses() {
		System.out.println("======  MainApplication.getClasses()  ======");
		Set<Class<?>> resources = new HashSet<>();
		resources.add(CarResource.class);
		return resources;
	}

}