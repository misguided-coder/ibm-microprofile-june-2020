package com.example;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/api")
public class MSApplication extends Application {

	public MSApplication(){
		System.out.println("======  MSApplication  ======");
	}
}