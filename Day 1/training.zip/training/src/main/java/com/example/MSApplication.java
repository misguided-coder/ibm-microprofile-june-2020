package com.example;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("api")
public class MSApplication extends Application {

	public MSApplication(){
		System.out.println("======  MSApplication  ======");
	}
	
	@Override
	public Set<Class<?>> getClasses() {
		System.out.println("===== MSApplication.getClasses()  =====");
		Set<Class<?>> classes = new HashSet<>();
		classes.add(PersonResource.class);
		return classes;
	}
	
}