package com.example;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/person")
public class PersonResource {

	@GET
	//@Produces("application/json")  //Content-Type=application/json
	@Produces(MediaType.APPLICATION_JSON)  //Content-Type=application/json
	public String info() {
		System.out.println("======  PersonResource.info() ======");
		return "{\"name\":\"Jaggu\",\"age\":26}";
	}
	
	@GET
	//@Produces("text/plain")  //Content-Type=text/plain
	@Produces(MediaType.TEXT_PLAIN)  //Content-Type=text/plain
	public String details() {
		System.out.println("======  PersonResource.details() ======");
		return "Name - Jaggu, Age - 26";
	}

	@GET
	//@Produces("application/xml")  //Content-Type=application/xml
	@Produces(MediaType.APPLICATION_XML)  //Content-Type=application/xml
	public String detailsAsXML() {
		System.out.println("======  PersonResource.detailsAsXML() ======");
		return "<person><name>Jaggu</name><age>26</age></person>";
	}

	@GET
	@Path("/address")
	@Produces("text/plain")  //Content-Type=text/plain
	public String addressOnly() {
		System.out.println("======  PersonResource.addressOnly() ======");
		return "City -Delhi";
	}
}