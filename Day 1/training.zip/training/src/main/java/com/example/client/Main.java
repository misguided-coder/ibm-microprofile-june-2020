package com.example.client;

import java.net.URI;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.rest.client.RestClientBuilder;

public class Main {

	public static void main(String[] args) {

		UC1();
		//UC2();
	}

	//Microprofile Type Safe REST Client
	private static void UC2() {
	
		IPersonResource proxyClient = RestClientBuilder.newBuilder()
			.baseUri(URI.create("http://localhost:9080/training/api/"))
			.register(RequestLogFilter.class)
			.build(IPersonResource.class);
		
		//String data = proxyClient.details();
		//System.out.println(data);
		String data = proxyClient.info();
		System.out.println(data);
		
		
	}
	
	//JAX-RS Client
	private static void UC1() {
		Client client = ClientBuilder.newClient();
		WebTarget webTarget = client.target("http://localhost:9080/training/api/person");
		Response response = webTarget.request().accept("application/json").get();
		String data = response.readEntity(String.class);
		System.out.println(data);
		System.out.println("Finish!!!!!");
	}

}
