package com.example.hotel;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.enterprise.context.Dependent;


public class HotelService {
	
	List<Hotel> hotels = new ArrayList<>();

	@PostConstruct
	public void init() {
		System.out.println("===== Inside HotelService init() =====");
		hotels.add(new Hotel(1000, "Taj Palace", "New Delhi", 600, LocalDate.now()));
		hotels.add(new Hotel(1001, "Hyatt", "New Delhi", 400, LocalDate.now()));
		hotels.add(new Hotel(1002, "Radisson", "New Delhi", 200, LocalDate.now()));
		hotels.add(new Hotel(1003, "Holiday Inn", "New Delhi", 600, LocalDate.now()));
	}

	@PreDestroy
	public void clean() {
		System.out.println("===== Inside HotelService clean() =====");
		hotels.clear();
		hotels = null;
	}

	public List<Hotel> readAllHotels() {
		return hotels;
	}

	public Hotel readHotel() {
		return new Hotel(1003, "Holiday Inn", "New Delhi", 600, LocalDate.now());
	}

}
