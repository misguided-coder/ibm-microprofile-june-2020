package com.example.hotel;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/")
public class HotelResource {

	@Inject
	HotelService hotelService;

	public HotelResource() {
		System.out.println("======  HotelResource ======");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/v2")
	public Hotel getHotelV2() {
		System.out.println("======  HotelResource.getHotelV2() ======");
		// Make call to business services and will return application specific domain
		// object
		return hotelService.readHotel();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/v1")
	public Hotel getHotelV1() {
		System.out.println("======  HotelResource.getHotelV1() ======");
		// Make call to business services and will return application specific domain
		// object
		HotelService hotelService = new HotelService();
		return hotelService.readHotel();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/list")
	public List<Hotel> getHotelList() {
		System.out.println("======  HotelResource.getHotelList() ======");
		return hotelService.readAllHotels();
	}
	

}