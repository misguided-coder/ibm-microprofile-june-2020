package com.example.hotel;

import java.time.LocalDate;

import javax.json.bind.annotation.JsonbDateFormat;
import javax.json.bind.annotation.JsonbNillable;
import javax.json.bind.annotation.JsonbProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.json.bind.annotation.JsonbTransient;

@JsonbNillable(value = false)
@JsonbPropertyOrder(value = { "id", "title", "place", "rooms" })
public class Hotel {

	@JsonbProperty(value = "hotelId")
	int id;

	@JsonbProperty(value = "title", nillable = false)
	String title;

	String place;

	@JsonbTransient
	int rooms;

	@JsonbDateFormat(value = "dd-MM-yyyy")
	LocalDate establishDate;

	public Hotel() {
	}

	public Hotel(String title, String place, int rooms) {
		this.title = title;
		this.place = place;
		this.rooms = rooms;
	}

	public Hotel(int id, String title, String place, int rooms, LocalDate establishDate) {
		this.id = id;
		this.title = title;
		this.place = place;
		this.rooms = rooms;
		this.establishDate = establishDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public int getRooms() {
		return rooms;
	}

	public void setRooms(int rooms) {
		this.rooms = rooms;
	}

	public LocalDate getEstablishDate() {
		return establishDate;
	}

	public void setEstablishDate(LocalDate establishDate) {
		this.establishDate = establishDate;
	}

}
