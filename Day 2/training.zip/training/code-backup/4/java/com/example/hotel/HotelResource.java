package com.example.hotel;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/")
public class HotelResource {

	public HotelResource() {
		System.out.println("======  HotelResource ======");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/v5")
	public Hotel getHotelV5() {
		System.out.println("======  HotelResource.getHotelV5() ======");

		// Make call to business services and will return application specific domain
		// object
		Hotel hotel = new Hotel(1000, "Taj Palace", "New Delhi", 600, LocalDate.now());

		return hotel;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/v4")
	public Hotel getHotelV4() {
		System.out.println("======  HotelResource.getHotelV4() ======");

		// Make call to other MS which is returing raw and plain json string
		String hotelDetails = "{\"id\": 1003,\"place\":\"New Delhi\",\"rooms\": 600,\"title\":\"Holiday Inn\"}";

		// JSON-B used to convert from raw valid JSON string to Java POJO
		Jsonb jsonb = JsonbBuilder.create();
		Hotel hotel = jsonb.fromJson(hotelDetails, Hotel.class);
		return hotel;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/v3")
	public String getHotelV3() {
		System.out.println("======  HotelResource.getHotelV3() ======");

		// Make call to business services and will return application specific domain
		// object
		List<Hotel> hotels = new ArrayList<>();
		hotels.add(new Hotel(1000, "Taj Palace", "New Delhi", 600, LocalDate.now()));
		hotels.add(new Hotel(1001, "Hyatt", "New Delhi", 400, LocalDate.now()));
		hotels.add(new Hotel(1002, "Radisson", "New Delhi", 200, LocalDate.now()));
		hotels.add(new Hotel(1003, "Holiday Inn", "New Delhi", 600, LocalDate.now()));

		// JSON-B used to convert from Java POJO to valid JSON string
		Jsonb jsonb = JsonbBuilder.create();
		String validJson = jsonb.toJson(hotels);
		return validJson;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/v2")
	public String getHotelV2() {
		System.out.println("======  HotelResource.getHotelV2() ======");

		// Make call to business services and will return application specific domain
		// object
		Hotel hotel = new Hotel(1000, "Taj Palace", "New Delhi", 600, LocalDate.now());

		// JSON-B used to convert from Java POJO to valid JSON string
		Jsonb jsonb = JsonbBuilder.create();
		String validJson = jsonb.toJson(hotel);
		return validJson;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/v1")
	public String getHotelV1() {
		System.out.println("======  HotelResource.getHotelV1() ======");

		// Make call to business services and will return application specific domain
		// object
		Hotel hotel = new Hotel(1000, "Taj Palace", "New Delhi", 600, LocalDate.now());

		// JSON-B used to convert from Java POJO to valid JSON string
		Jsonb jsonb = JsonbBuilder.create();
		String validJson = jsonb.toJson(hotel);
		return validJson;
	}

}