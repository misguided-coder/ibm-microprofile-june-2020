package com.example.hotel;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/hotel")
public class HotelApplication extends Application {

	public HotelApplication(){
		System.out.println("======  HotelApplication  ======");
	}
	
	@Override
	public Set<Class<?>> getClasses() {
		System.out.println("======  HotelApplication.getClasses()  ======");
		Set<Class<?>> resources = new HashSet<>();
		resources.add(HotelResource.class);
		resources.add(RoomResource.class);
		return resources;
	}
			
}